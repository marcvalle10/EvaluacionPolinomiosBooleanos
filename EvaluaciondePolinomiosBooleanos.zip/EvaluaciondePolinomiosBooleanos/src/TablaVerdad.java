import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TablaVerdad {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el polinomio booleano:");
        String input = scanner.nextLine();

        // Validación de la entrada
        if (!validarExpresion(input)) {
            System.out.println("Expresión inválida.");
            return;
        }

        int numVariables = calcularNumeroVariables(input);
        int totalCombinaciones = (1 << numVariables);

        List<String> variables = obtenerVariables(input);
        List<String> expresiones = generarExpresiones(input, variables);

        // Imprimir encabezado de la tabla de verdad
        for (String variable : variables) {
            System.out.print(variable + "\t");
        }
        System.out.println("| Expresiones\t| Resultado");

        // Imprimir separador
        for (int j = 0; j < variables.size(); j++) {
            System.out.print("--------");
        }
        System.out.println("+-------------------+----------");

        for (int i = 0; i < totalCombinaciones; i++) {
            String binary = String.format("%0" + numVariables + "d", Integer.parseInt(Integer.toBinaryString(i)));

            List<Boolean> results = new ArrayList<>();
            for (String expresion : expresiones) {
                boolean result = evaluarExpresion(expresion, binary);
                results.add(result);
            }

            imprimirFilaTabla(variables, expresiones, binary, results);
        }
    }

    private static boolean validarExpresion(String expression) {
        // Agrega lógica de validación de la expresión aquí
        // Devuelve true si la expresión es válida, false si no lo es
        return true; // Cambiar a la lógica de validación real
    }

    private static int calcularNumeroVariables(String expression) {
        int count = 0;
        for (char c : expression.toCharArray()) {
            if (Character.isLetter(c) && Character.isLowerCase(c)) {
                count++;
            }
        }
        return count;
    }

    private static List<String> obtenerVariables(String expression) {
        List<String> variables = new ArrayList<>();
        for (char c : expression.toCharArray()) {
            if (Character.isLetter(c) && Character.isLowerCase(c) && !variables.contains(String.valueOf(c))) {
                variables.add(String.valueOf(c));
            }
        }
        return variables;
    }

    private static List<String> generarExpresiones(String input, List<String> variables) {
        List<String> expresiones = new ArrayList<>();
        // Reemplazar " v " por " || " entre variables en las expresiones
        String inputModified = input.replaceAll(" v ", " || ");
        expresiones.add(inputModified);
        return expresiones;
    }

    private static boolean evaluarExpresion(String expression, String binary) {
        // Agrega la lógica de evaluación de expresiones aquí
        // Devuelve true o false según la evaluación de la expresión
        return true; // Cambiar a la lógica de evaluación real
    }

    private static void imprimirFilaTabla(List<String> variables, List<String> expresiones, String binary, List<Boolean> results) {
        for (String variable : variables) {
            System.out.print(binary.charAt(variables.indexOf(variable)) + "\t");
        }

        System.out.print("| ");

        for (String expresion : expresiones) {
            System.out.print(expresion + "\t");
        }

        System.out.print("| ");

        boolean finalResult = true;
        for (boolean result : results) {
            System.out.print((result ? "1" : "0") + "\t");
            finalResult &= result;
        }

        System.out.println("| " + (finalResult ? "1" : "0"));
    }
}